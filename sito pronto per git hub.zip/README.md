# AI Generated Website

This website was generated using AI and modified for GitHub deployment.

## Setup

1. Clone this repository
2. Run `npm install`
3. Run `npm run dev` for development
4. Run `npm run build` for production
